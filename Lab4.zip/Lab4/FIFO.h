#ifndef FIFO_H_INCLUDED
#define FIFO_H_INCLUDED

void FIFO(int * page, int n,int *frame,int nf,char * type);

#endif