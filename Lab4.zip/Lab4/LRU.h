#ifndef LRU_H_INCLUDED
#define LRU_H_INCLUDED

void LRU(int * page, int n,int *frame,int nf,char * type);

#endif