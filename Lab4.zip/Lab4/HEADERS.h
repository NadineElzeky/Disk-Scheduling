#include "FIFO.h"
#include "OPTIMAL.h"
#include "CLOCK.h"
#include "LRU.h"