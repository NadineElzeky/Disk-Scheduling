#ifndef CLOCK_H_INCLUDED
#define CLOCK_H_INCLUDED

void clock(int * page, int n,int *frame,int nf,char * type);

#endif