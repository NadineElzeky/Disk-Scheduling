#ifndef OPTIMAL_H_INCLUDED
#define OPTIMAL_H_INCLUDED


void optimal(int * page, int n,int *frame,int nf,char * type);

#endif